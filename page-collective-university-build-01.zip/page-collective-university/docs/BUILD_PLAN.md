# Page Collective University — Build plan

## Product principles
1. Knowledge should lead to practice, not only content consumption.
2. Mobile-first access; low-friction navigation and readable pages.
3. Students own their personal learning records; privileged actions are restricted.
4. Every feature must be tested end-to-end before it is called complete.
5. No claim of academic accreditation unless a real approval/partnership exists.

## First production milestones

### Milestone 1 — Foundation
- [x] Separate application identity and public landing page
- [x] Initial school catalogue and programme catalogue route
- [x] Supabase auth integration foundation
- [x] Initial university database entities and RLS policy draft
- [ ] Configure a dedicated Supabase project
- [ ] Run and validate schema against fresh database
- [ ] Install packages and pass a clean production build
- [ ] Automated auth, permissions, and smoke tests

### Milestone 2 — Academic delivery
- [ ] School/programme/course authoring and publishing
- [ ] Enrolment lifecycle
- [ ] Lesson completion and progress calculation
- [ ] Assignment submission and instructor review
- [ ] Certificate issuance and public verification

### Milestone 3 — Student experience
- [ ] Student profile and preferences
- [ ] Search and filtering across catalogue
- [ ] Student dashboard with accurate learning data
- [ ] Notification centre and email delivery
- [ ] Accessible responsive layouts

### Milestone 4 — Community and operations
- [ ] Study groups and discussion moderation
- [ ] Events, attendance, and reminders
- [ ] Opportunities directory
- [ ] Admin analytics and audit trail
- [ ] Privacy, account deletion, backups, monitoring, and incident process

### Milestone 5 — Launch readiness
- [ ] Security review and RLS tests
- [ ] End-to-end tests with student, instructor, moderator, and admin roles
- [ ] Mobile and cross-browser testing
- [ ] Terms, privacy notice, community rules, and content rights review
- [ ] Production environment variables and deployment
- [ ] Live smoke test and rollback plan
