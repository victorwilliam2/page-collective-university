import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

const pillars = [
  { n: "01", title: "Learn with purpose", text: "Explore structured courses, reading pathways, and practical learning experiences." },
  { n: "02", title: "Grow in community", text: "Exchange ideas, join study circles, and learn alongside people who challenge you to grow." },
  { n: "03", title: "Apply what you know", text: "Turn insight into projects, habits, creative work, and contributions that matter." },
];

export default async function Home() {
  let books = 0, courses = 0, events = 0;
  try {
    const db = createClient();
    const [b, c, e] = await Promise.all([
      db.from("books").select("id", { count: "exact", head: true }).eq("is_published", true),
      db.from("courses").select("id", { count: "exact", head: true }).eq("is_published", true),
      db.from("events").select("id", { count: "exact", head: true }).eq("is_published", true),
    ]);
    books = b.count || 0; courses = c.count || 0; events = e.count || 0;
  } catch { /* The public landing page works while backend credentials are being configured. */ }
  return <>
    <section className="hero university-hero"><div className="container hero-grid"><div className="hero-copy"><span className="eyebrow hero-eyebrow">A university without walls</span><h1>Knowledge that<br/>changes <em>what's possible.</em></h1><p>Page Collective University is a digital learning community built to help people read deeply, develop useful skills, think independently, and turn knowledge into meaningful action.</p><div className="hero-actions"><Link className="btn" href="/register">Begin your journey <span aria-hidden="true">↗</span></Link><Link className="btn secondary" href="/schools">Explore our schools</Link></div><div className="hero-note"><span className="hero-dot"/> Learn at your pace. Grow with purpose. Build with others.</div></div><div className="hero-art" aria-label="University learning philosophy"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="art-center"><span className="monogram">P<span>·</span>C</span><span className="art-caption">PAGE COLLECTIVE<br/>UNIVERSITY</span></div><div className="floating-note note-top"><span>01 / MIND</span><strong>Think deeply.</strong></div><div className="floating-note note-bottom"><span>02 / PRACTICE</span><strong>Build something real.</strong></div><span className="art-spark spark-one">✳</span><span className="art-spark spark-two">✳</span></div></div></section>
    <section className="intro-strip"><div className="container intro-inner"><span>OUR LEARNING CYCLE</span><p>READ <i>→</i> LEARN <i>→</i> THINK <i>→</i> BUILD <i>→</i> TRANSFORM</p></div></section>
    <section className="section"><div className="container"><div className="section-heading"><div><span className="eyebrow">More than information</span><h2>Learn for the life<br/>you're building.</h2></div><p className="muted">A university should do more than deliver content. It should create the conditions for curiosity, capability, community, and contribution to grow together.</p></div><div className="grid pillar-grid">{pillars.map(p=><article className="card pillar-card" key={p.n}><span className="pillar-number">{p.n}</span><h3>{p.title}</h3><p>{p.text}</p></article>)}</div></div></section>
    <section className="schools-band"><div className="container"><div className="section-heading"><div><span className="eyebrow">Seven learning communities</span><h2>Find your next direction.</h2></div><Link className="text-link" href="/schools">View all schools ↗</Link></div><div className="school-preview-grid">{[{t:"Literature & Intellectual Development",n:"01"},{t:"Business & Entrepreneurship",n:"02"},{t:"Technology & Innovation",n:"03"},{t:"Personal Development & Leadership",n:"04"},{t:"Faith, Ethics & Character",n:"05"},{t:"Human Development",n:"06"},{t:"Creativity & African Expression",n:"07"}].map(s=><Link href="/schools" className="school-preview" key={s.n}><span>{s.n}</span><strong>{s.t}</strong><b>↗</b></Link>)}</div></div></section>
    <section className="section"><div className="container"><div className="section-heading"><div><span className="eyebrow">Your next step</span><h2>A place to begin.<br/>Room to become.</h2></div><p className="muted">Explore the learning resources and community features currently available. The university will grow in deliberate stages, with each new feature tested before launch.</p></div><div className="grid resource-grid">{[{t:"Digital Library",p:"Discover reading resources and track your progress.",h:"/library",icon:"↗"},{t:"Courses & Learning",p:"Explore published courses and structured lessons.",h:"/courses",icon:"◫"},{t:"Community Room",p:"Exchange reflections and build on ideas together.",h:"/community",icon:"◎"},{t:"Events & Experiences",p:"Find reading circles, workshops, and gatherings.",h:"/events",icon:"✳"}].map(x=><Link className="card resource-card" href={x.h} key={x.t}><span className="resource-icon">{x.icon}</span><h3>{x.t}</h3><p>{x.p}</p><b>Explore <span>→</span></b></Link>)}</div><div className="stats-band"><div><strong>{books}</strong><span>Published library resources</span></div><div><strong>{courses}</strong><span>Published courses</span></div><div><strong>{events}</strong><span>Published events</span></div><p>We publish learning experiences when they're ready—not just to fill a catalogue.</p></div></div></section>
    <section className="closing-band"><div className="container closing-inner"><div><span className="eyebrow">Your growth starts here</span><h2>Don't just collect knowledge.<br/><em>Become changed by it.</em></h2></div><Link className="btn light-btn" href="/register">Join Page Collective University ↗</Link></div></section>
  </>;
}
