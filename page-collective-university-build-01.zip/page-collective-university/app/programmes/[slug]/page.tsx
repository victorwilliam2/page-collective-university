import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ProgrammeDetail({ params }: { params: { slug: string } }) {
  let programme: any = null;
  let courses: any[] = [];
  let user: any = null;
  try {
    const db = createClient();
    const auth = await db.auth.getUser(); user = auth.data.user;
    const query = /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(params.slug)
      ? db.from("programmes").select("*, schools(name,slug)").eq("id", params.slug)
      : db.from("programmes").select("*, schools(name,slug)").eq("slug", params.slug);
    const result = await query.eq("is_published", true).maybeSingle();
    programme = result.data;
    if (programme) {
      const related = await db.from("courses").select("id,title,description,level,estimated_hours").eq("programme_id", programme.id).eq("is_published", true).order("created_at");
      courses = related.data || [];
    }
  } catch { /* Missing backend configuration is handled by the empty state. */ }
  if (!programme) return <main className="container page"><div className="empty"><h1>Programme not found</h1><p>This programme may not be published yet.</p><Link className="btn" href="/programmes">Back to programmes</Link></div></main>;
  return <main className="container page"><div className="page-title"><Link className="text-link" href="/programmes">← All programmes</Link><p><span className="pill">{programme.level || "Open level"}</span></p><span className="eyebrow">{programme.schools?.name || "Page Collective University"}</span><h1>{programme.title}</h1><p className="muted">{programme.description}</p><p className="muted">{programme.duration || "Self-paced learning"}</p></div><div className="grid two"><section className="card"><h2>What you'll work toward</h2>{programme.learning_outcomes?.length ? <ul>{programme.learning_outcomes.map((o: string) => <li key={o}>{o}</li>)}</ul> : <p className="muted">Learning outcomes will be published with the full programme syllabus.</p>}</section><section className="card"><h2>Join this programme</h2>{user ? <form action="/programmes/enroll" method="post"><input type="hidden" name="programme_id" value={programme.id}/><p className="muted">Enrolment will be saved to your student account.</p><button type="submit">Enrol in programme →</button></form> : <><p className="muted">Sign in or create an account to enrol and keep track of your learning.</p><Link className="btn" href="/register">Create student account</Link></>}</section></div><section className="section"><h2>Courses in this programme</h2>{courses.length ? <div className="grid">{courses.map(c => <article className="card" key={c.id}><span className="pill">{c.level || "Course"}</span><h3>{c.title}</h3><p>{c.description}</p><p className="muted">{c.estimated_hours ? `${c.estimated_hours} estimated hours` : "Flexible pace"}</p><Link className="text-link" href={`/courses/${c.id}`}>Open course →</Link></article>)}</div> : <div className="empty">Course modules are being prepared for this programme.</div>}</section></main>;
}
