import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function ProgrammesPage() {
  let programmes: any[] = [];
  try {
    const db = createClient();
    const { data } = await db.from("programmes").select("*, schools(name, slug)").eq("is_published", true).order("created_at", { ascending: false });
    programmes = data || [];
  } catch { /* The public page remains available before environment setup. */ }
  return <main className="container page">
    <div className="page-title"><span className="eyebrow">Study at your pace</span><h1>Programmes & learning pathways</h1><p className="muted">Structured journeys designed to turn curiosity into capability. New programmes will appear here when the academic team publishes them.</p></div>
    {programmes.length ? <div className="grid">{programmes.map(p => <article className="card" key={p.id}><span className="pill">{p.level || "Open level"}</span><h2>{p.title}</h2><p>{p.description}</p><p className="muted">{p.schools?.name || "Page Collective University"} · {p.duration || "Self-paced"}</p><Link className="btn" href={`/programmes/${p.slug || p.id}`}>View programme →</Link></article>)}</div> : <div className="empty"><h2>The catalogue is being prepared.</h2><p>Our schools and learning philosophy are mapped out. Programme pages will be published as course content, learning outcomes, and assessments are ready.</p><Link className="btn" href="/schools">Explore the schools</Link></div>}
  </main>;
}
