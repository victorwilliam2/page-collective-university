import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const db = createClient();
  const { data: { user } } = await db.auth.getUser();
  if (!user) redirect("/login");
  const form = await request.formData();
  const programmeId = String(form.get("programme_id") || "");
  if (!programmeId) redirect("/programmes");
  const { error } = await db.from("enrollments").upsert({ user_id: user.id, programme_id: programmeId, status: "active" }, { onConflict: "user_id,programme_id", ignoreDuplicates: true });
  if (error) redirect(`/programmes?enrolment=error`);
  redirect(`/dashboard?enrolled=1`);
}
