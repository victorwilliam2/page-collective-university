import Link from "next/link";

const schools = [
  { n: "01", title: "Literature & Intellectual Development", short: "Think more clearly. Read more deeply.", text: "Reading practice, critical thinking, writing, research, African literature, and thoughtful discussion.", tags: ["Reading", "Critical thinking", "Writing"] },
  { n: "02", title: "Business & Entrepreneurship", short: "Turn ideas into useful work.", text: "Entrepreneurship, financial literacy, business planning, marketing, and practical venture-building.", tags: ["Business", "Finance", "Enterprise"] },
  { n: "03", title: "Technology & Innovation", short: "Build for the world you want.", text: "Digital literacy, software, data, AI awareness, product thinking, and hands-on projects.", tags: ["Digital skills", "Data", "Innovation"] },
  { n: "04", title: "Personal Development & Leadership", short: "Become more intentional.", text: "Communication, discipline, leadership, productivity, goal-setting, and responsible influence.", tags: ["Leadership", "Habits", "Communication"] },
  { n: "05", title: "Faith, Ethics & Character", short: "Let knowledge shape character.", text: "Faith-centred learning, ethical reflection, service, integrity, and principled leadership.", tags: ["Character", "Ethics", "Reflection"] },
  { n: "06", title: "Human Development", short: "Understand yourself and others.", text: "Self-awareness, emotional intelligence, relationships, resilience, and healthy communication.", tags: ["Self-awareness", "Relationships", "Resilience"] },
  { n: "07", title: "Creativity & African Expression", short: "Tell stories that move people.", text: "Creative writing, spoken word, storytelling, African thought, publishing, and collaborative projects.", tags: ["Writing", "Culture", "Publishing"] },
];

export default function SchoolsPage() {
  return <main className="container page">
    <div className="page-title"><span className="eyebrow">Explore the university</span><h1>Seven schools. One commitment to growth.</h1><p className="muted">Our schools organise learning around the capabilities people need to think, build, contribute, and live with intention. Programmes will be published as they are developed and reviewed.</p></div>
    <div className="grid">{schools.map(s => <article className="card school-card" key={s.n}><span className="school-number">{s.n}</span><h2>{s.title}</h2><strong>{s.short}</strong><p>{s.text}</p><div className="tag-row">{s.tags.map(t => <span className="pill" key={t}>{t}</span>)}</div><Link className="text-link" href="/programmes">Explore programmes →</Link></article>)}</div>
    <section className="callout"><span className="eyebrow">Learning philosophy</span><h2>Knowledge should travel beyond the classroom.</h2><p>We want students to read, reflect, practise, create, share, and apply what they learn in real life.</p><b>READ → LEARN → THINK → BUILD → TRANSFORM</b></section>
  </main>;
}
