create extension if not exists pgcrypto;
do $$ begin create type public.member_role as enum ('member','moderator','admin'); exception when duplicate_object then null; end $$;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,email text unique,full_name text not null default 'Page Collective Member',bio text,avatar_url text,role public.member_role not null default 'member',growth_points integer not null default 0,streak_days integer not null default 0,created_at timestamptz not null default now());
create table if not exists public.books(id uuid primary key default gen_random_uuid(),title text not null,author text,category text,description text,resource_url text,cover_url text,is_published boolean not null default true,created_by uuid references public.profiles(id) on delete set null,created_at timestamptz not null default now());
create table if not exists public.reading_progress(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id) on delete cascade,book_id uuid not null references public.books(id) on delete cascade,progress_percent integer not null default 0 check(progress_percent between 0 and 100),notes text,started_at timestamptz not null default now(),completed_at timestamptz,updated_at timestamptz not null default now(),unique(user_id,book_id));
create table if not exists public.courses(id uuid primary key default gen_random_uuid(),title text not null,category text,level text,description text,is_published boolean not null default true,created_by uuid references public.profiles(id) on delete set null,created_at timestamptz not null default now());
create table if not exists public.lessons(id uuid primary key default gen_random_uuid(),course_id uuid not null references public.courses(id) on delete cascade,title text not null,summary text,body text,content_url text,position integer not null default 0,is_published boolean not null default true,created_at timestamptz not null default now());
create table if not exists public.lesson_progress(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id) on delete cascade,lesson_id uuid not null references public.lessons(id) on delete cascade,completed_at timestamptz,unique(user_id,lesson_id));
create table if not exists public.posts(id uuid primary key default gen_random_uuid(),author_id uuid not null references public.profiles(id) on delete cascade,title text not null,body text not null,is_published boolean not null default true,created_at timestamptz not null default now());
create table if not exists public.comments(id uuid primary key default gen_random_uuid(),post_id uuid not null references public.posts(id) on delete cascade,author_id uuid not null references public.profiles(id) on delete cascade,body text not null,created_at timestamptz not null default now());
create table if not exists public.events(id uuid primary key default gen_random_uuid(),title text not null,event_type text,description text,starts_at timestamptz not null,location text,capacity integer check(capacity is null or capacity>0),is_published boolean not null default true,created_by uuid references public.profiles(id) on delete set null,created_at timestamptz not null default now());
create table if not exists public.event_registrations(id uuid primary key default gen_random_uuid(),event_id uuid not null references public.events(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now(),unique(event_id,user_id));
create table if not exists public.announcements(id uuid primary key default gen_random_uuid(),title text not null,body text not null,is_published boolean not null default true,created_by uuid references public.profiles(id) on delete set null,created_at timestamptz not null default now());
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,email,full_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name','Page Collective Member')) on conflict(id) do update set email=excluded.email; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
alter table public.profiles enable row level security;alter table public.books enable row level security;alter table public.reading_progress enable row level security;alter table public.courses enable row level security;alter table public.lessons enable row level security;alter table public.lesson_progress enable row level security;alter table public.posts enable row level security;alter table public.comments enable row level security;alter table public.events enable row level security;alter table public.event_registrations enable row level security;alter table public.announcements enable row level security;
create policy "profiles signed in read" on public.profiles for select to authenticated using(true);
create policy "profile owner update" on public.profiles for update to authenticated using(auth.uid()=id) with check(auth.uid()=id);
create policy "admin profile management" on public.profiles for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "published books read" on public.books for select using(is_published or public.is_admin());
create policy "admin books management" on public.books for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "own reading progress read" on public.reading_progress for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "own reading progress insert" on public.reading_progress for insert to authenticated with check(user_id=auth.uid());
create policy "own reading progress update" on public.reading_progress for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "own reading progress delete" on public.reading_progress for delete to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "published courses read" on public.courses for select using(is_published or public.is_admin());
create policy "admin courses management" on public.courses for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "published lessons read" on public.lessons for select using(is_published or public.is_admin());
create policy "admin lessons management" on public.lessons for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "own lesson progress read" on public.lesson_progress for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "own lesson progress insert" on public.lesson_progress for insert to authenticated with check(user_id=auth.uid());
create policy "own lesson progress update" on public.lesson_progress for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "published posts read" on public.posts for select using(is_published or author_id=auth.uid() or public.is_admin());
create policy "members create own posts" on public.posts for insert to authenticated with check(author_id=auth.uid());
create policy "authors update posts" on public.posts for update to authenticated using(author_id=auth.uid() or public.is_admin()) with check(author_id=auth.uid() or public.is_admin());
create policy "authors delete posts" on public.posts for delete to authenticated using(author_id=auth.uid() or public.is_admin());
create policy "comments signed in read" on public.comments for select to authenticated using(true);
create policy "members create comments" on public.comments for insert to authenticated with check(author_id=auth.uid());
create policy "authors delete comments" on public.comments for delete to authenticated using(author_id=auth.uid() or public.is_admin());
create policy "published events read" on public.events for select using(is_published or public.is_admin());
create policy "admin events management" on public.events for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "own event registrations read" on public.event_registrations for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "register self" on public.event_registrations for insert to authenticated with check(user_id=auth.uid());
create policy "cancel own registration" on public.event_registrations for delete to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "published announcements read" on public.announcements for select using(is_published or public.is_admin());
create policy "admin announcements management" on public.announcements for all to authenticated using(public.is_admin()) with check(public.is_admin());
create index if not exists posts_created_idx on public.posts(created_at desc);create index if not exists events_start_idx on public.events(starts_at);create index if not exists reading_user_idx on public.reading_progress(user_id);create index if not exists comments_post_idx on public.comments(post_id,created_at);
insert into public.books(title,author,category,description) values('The Beautiful Ones Are Not Yet Born','Ayi Kwei Armah','African literature','A novel for discussion about conscience, corruption, and society.'),('Atomic Habits','James Clear','Personal development','A popular book about small habits and consistent improvement.') on conflict do nothing;
insert into public.courses(title,category,level,description) values('Reading with Intention','Reading skills','Beginner','Build a repeatable reading practice: prepare, read, reflect, and apply.'),('Turning Ideas into Action','Personal growth','Beginner','A practical path from insight to measurable personal action.') on conflict do nothing;
insert into public.events(title,event_type,description,starts_at,location) values('Community Reading Circle','Reading discussion','SAMPLE EVENT — replace this with real details before launch.',now()+interval '14 days','Online / to be confirmed') on conflict do nothing;


-- Prevent members from promoting themselves by changing their own profile role.
create or replace function public.protect_profile_role()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.role is distinct from old.role and not public.is_admin() then
    raise exception 'Only an administrator can change member roles';
  end if;
  return new;
end;
$$;
drop trigger if exists protect_profile_role_trigger on public.profiles;
create trigger protect_profile_role_trigger
before update on public.profiles
for each row execute procedure public.protect_profile_role();


-- UNIVERSITY LAYER: schools, programmes, assessments, certificates, notifications and opportunities.
create table if not exists public.schools (
  id uuid primary key default gen_random_uuid(), name text not null, slug text not null unique,
  tagline text, description text, is_published boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.programmes (
  id uuid primary key default gen_random_uuid(), school_id uuid references public.schools(id) on delete set null,
  title text not null, slug text not null unique, description text, level text, duration text,
  learning_outcomes text[] not null default '{}', is_published boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null, created_at timestamptz not null default now()
);
alter table public.courses add column if not exists school_id uuid references public.schools(id) on delete set null;
alter table public.courses add column if not exists programme_id uuid references public.programmes(id) on delete set null;
alter table public.courses add column if not exists estimated_hours integer check (estimated_hours is null or estimated_hours > 0);
create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  programme_id uuid not null references public.programmes(id) on delete cascade,
  status text not null default 'active' check (status in ('active','completed','paused','withdrawn')),
  enrolled_at timestamptz not null default now(), completed_at timestamptz, unique(user_id, programme_id)
);
create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
  title text not null, instructions text not null, due_at timestamptz, max_score numeric(7,2) not null default 100 check(max_score > 0),
  is_published boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(), assignment_id uuid not null references public.assignments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade, response_text text, file_url text,
  status text not null default 'submitted' check(status in ('draft','submitted','reviewed','returned')),
  score numeric(7,2), feedback text, submitted_at timestamptz not null default now(), reviewed_at timestamptz,
  unique(assignment_id,user_id), check(response_text is not null or file_url is not null)
);
create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  programme_id uuid references public.programmes(id) on delete set null, course_id uuid references public.courses(id) on delete set null,
  certificate_code text not null unique, issued_at timestamptz not null default now(),
  issued_by uuid references public.profiles(id) on delete set null, public_verification_enabled boolean not null default true,
  check(programme_id is not null or course_id is not null)
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, body text not null, href text, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(), title text not null, organisation text, opportunity_type text,
  description text not null, application_url text, deadline timestamptz, is_published boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null, created_at timestamptz not null default now()
);
alter table public.schools enable row level security;
alter table public.programmes enable row level security;
alter table public.enrollments enable row level security;
alter table public.assignments enable row level security;
alter table public.submissions enable row level security;
alter table public.certificates enable row level security;
alter table public.notifications enable row level security;
alter table public.opportunities enable row level security;
create policy "published schools visible" on public.schools for select using(is_published or public.is_admin());
create policy "admin manages schools" on public.schools for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "published programmes visible" on public.programmes for select using(is_published or public.is_admin());
create policy "admin manages programmes" on public.programmes for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "members read own enrolments" on public.enrollments for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "members enrol themselves" on public.enrollments for insert to authenticated with check(user_id=auth.uid());
create policy "admin manages enrolments" on public.enrollments for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "published assignments visible" on public.assignments for select using(is_published or public.is_admin());
create policy "admin manages assignments" on public.assignments for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "members read own submissions" on public.submissions for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "members submit own work" on public.submissions for insert to authenticated with check(user_id=auth.uid());
create policy "members update own unreviewed work" on public.submissions for update to authenticated using(user_id=auth.uid() and status in ('draft','submitted')) with check(user_id=auth.uid());
create policy "admin reviews submissions" on public.submissions for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "own certificates and public verification" on public.certificates for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "admin issues certificates" on public.certificates for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "members read own notifications" on public.notifications for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "members mark own notifications read" on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "admin creates notifications" on public.notifications for insert to authenticated with check(public.is_admin());
create policy "published opportunities visible" on public.opportunities for select using(is_published or public.is_admin());
create policy "admin manages opportunities" on public.opportunities for all to authenticated using(public.is_admin()) with check(public.is_admin());
create index if not exists programmes_school_idx on public.programmes(school_id);
create index if not exists enrolments_user_idx on public.enrollments(user_id, enrolled_at desc);
create index if not exists submissions_assignment_idx on public.submissions(assignment_id, submitted_at desc);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
create index if not exists opportunities_deadline_idx on public.opportunities(deadline);

insert into public.schools(name,slug,tagline,description) values
('Literature & Intellectual Development','literature-intellectual-development','Think more clearly. Read more deeply.','Reading practice, critical thinking, writing, research, African literature, and thoughtful discussion.'),
('Business & Entrepreneurship','business-entrepreneurship','Turn ideas into useful work.','Entrepreneurship, financial literacy, business planning, marketing, and practical venture-building.'),
('Technology & Innovation','technology-innovation','Build for the world you want.','Digital literacy, software, data, AI awareness, product thinking, and hands-on projects.'),
('Personal Development & Leadership','personal-development-leadership','Become more intentional.','Communication, discipline, leadership, productivity, goal-setting, and responsible influence.'),
('Faith, Ethics & Character','faith-ethics-character','Let knowledge shape character.','Faith-centred learning, ethical reflection, service, integrity, and principled leadership.'),
('Human Development','human-development','Understand yourself and others.','Self-awareness, emotional intelligence, relationships, resilience, and healthy communication.'),
('Creativity & African Expression','creativity-african-expression','Tell stories that move people.','Creative writing, spoken word, storytelling, African thought, publishing, and collaborative projects.')
on conflict(slug) do nothing;

-- Prevent students from editing their own marks or instructor feedback.
create or replace function public.protect_submission_review_fields()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if public.is_admin() then return new; end if;
  if old.user_id <> auth.uid() then raise exception 'You may only edit your own submission'; end if;
  if new.status not in ('draft','submitted') then raise exception 'Only draft or submitted status is allowed'; end if;
  new.score := old.score;
  new.feedback := old.feedback;
  new.reviewed_at := old.reviewed_at;
  return new;
end;
$$;
drop trigger if exists protect_submission_review_fields_trigger on public.submissions;
create trigger protect_submission_review_fields_trigger before update on public.submissions
for each row execute procedure public.protect_submission_review_fields();
drop policy if exists "members update own unreviewed work" on public.submissions;
create policy "members update own unreviewed work" on public.submissions for update to authenticated
using(user_id=auth.uid() and status in ('draft','submitted'))
with check(user_id=auth.uid() and status in ('draft','submitted'));
