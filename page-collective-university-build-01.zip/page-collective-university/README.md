# Page Collective University

**A university without walls.** This is a separate application for the new Page Collective University. It does not connect to or modify the existing Page Collective app.

This repository is the first development foundation: a Next.js application with Supabase authentication and database integration, a university-branded public homepage, school catalogue, programme catalogue, digital library, course pages, community discussions, events, member dashboard, and an administrator workspace. The SQL schema includes the initial university data model for schools, programmes, enrolments, courses, lessons, assignments, submissions, certificates, notifications, and opportunities.

> **Status:** Development foundation, not yet a production launch. External credentials are intentionally not included. Features requiring third-party configuration or additional implementation must be completed and tested before the platform is opened to real students.

## Stack
- Next.js 14 / React 18 / TypeScript
- Supabase Auth and PostgreSQL
- Row Level Security (RLS) policies
- Responsive CSS design system

## Run locally
1. Install Node.js 20 or newer.
2. Create a new Supabase project dedicated to Page Collective University.
3. In the Supabase SQL Editor, run `supabase/schema.sql` **once on a fresh project**.
4. Copy `.env.example` to `.env.local` and fill in the Supabase project URL and public anon key.
5. In Supabase Auth settings, set the local site URL to `http://localhost:3000` and allow that redirect URL.
6. In this folder, run `npm install`, then `npm run dev`.
7. Open `http://localhost:3000`.

## Create the first administrator
Register using the app, then run the following in the Supabase SQL Editor, replacing the email with the account you own:

```sql
update public.profiles
set role = 'admin'
where email = 'YOUR_EMAIL_ADDRESS';
```

Never place a Supabase service-role key in browser code or commit credentials to source control.

## Current working areas
- Public university homepage and school catalogue.
- Programme catalogue connected to the database when Supabase is configured.
- Authentication flows and member dashboard.
- Library and reading progress.
- Course and lesson foundation.
- Community posts and comments.
- Event listing and registration.
- Initial administrator publishing forms.
- Database tables and RLS policies for the academic foundation and planned university workflows.

## Still required before calling it complete
- Install dependencies and run a clean production build in an environment with package access.
- Run SQL against a fresh Supabase project and test every RLS policy with student and admin accounts.
- Build and test the full programme/lesson authoring and enrolment workflows.
- Complete assignment authoring, submissions, grading, certificate issue/verification, and opportunity-management interfaces.
- Implement notification creation, email delivery, and preferences; the table alone is not a notification system.
- Implement file upload, moderation tools, account deletion/privacy workflows, and accessibility checks.
- Add automated tests, error monitoring, backups, rate limiting, terms, privacy notice, and production configuration.
- Configure hosting, domain, email provider, and any payment integration only after the core application is tested.

## Important notes
- The schools seeded in the database and displayed on the site are proposed learning divisions. They do not imply formal accreditation.
- Seeded sample books/events are examples and must be reviewed or replaced before launch.
- Run the SQL schema only on a new dedicated project as currently written; it includes policies and sample data and is not intended as a repeatable migration script.
