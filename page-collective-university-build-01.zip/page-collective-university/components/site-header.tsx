import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export async function SiteHeader() {
  let signed = false;
  try { const db = createClient(); signed = !!(await db.auth.getUser()).data.user; } catch { /* Auth is configured during setup. */ }
  return <header className="top"><div className="container nav"><Link href="/" className="brand">P / PAGE COLLECTIVE <small style={{ display: "block", fontSize: 10, letterSpacing: 2 }}>UNIVERSITY</small></Link><nav className="links"><Link href="/schools">Schools</Link><Link href="/programmes">Programmes</Link><Link href="/library">Library</Link><Link href="/courses">Courses</Link><Link href="/community">Community</Link><Link href="/events">Events</Link><Link href={signed ? "/dashboard" : "/login"} className="btn">{signed ? "My space" : "Join / Log in"}</Link></nav></div></header>;
}
