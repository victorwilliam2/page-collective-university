import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(req: NextRequest) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  // Allow the public pages to render before the owner configures Supabase.
  if (!url || !anon) return NextResponse.next({ request: req });
  let res = NextResponse.next({ request: req });
  const db = createServerClient(url, anon, {
    cookies: {
      get: name => req.cookies.get(name)?.value,
      set(name, value, options) { req.cookies.set({ name, value, ...options }); res = NextResponse.next({ request: req }); res.cookies.set({ name, value, ...options }); },
      remove(name, options) { req.cookies.set({ name, value: "", ...options }); res = NextResponse.next({ request: req }); res.cookies.set({ name, value: "", ...options }); },
    },
  });
  await db.auth.getUser();
  return res;
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
